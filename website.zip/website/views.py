from flask import Blueprint, render_template, request
import joblib

views = Blueprint('views', __name__)

@views.route('/', methods=['GET','POST'])
def home():
    if request.method == 'POST':
        asked = request.form.get('question')
        file_model = open('filename.pkl', "rb")
        trained_model = joblib.load(file_model)
        answer = trained_model.get_answer_percontext([asked])
    return render_template("home.html")